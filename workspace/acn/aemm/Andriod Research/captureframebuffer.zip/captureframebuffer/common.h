#ifndef COMMON_H 
#define COMMON_H 
struct picture{ 
    int xres,yres; 
    char *buffer; 
    struct fb_cmap *colormap; 
    char bps,gray; 
}; 
int TakeScreenshot (const char* device, struct picture* pict); 
#endif 
