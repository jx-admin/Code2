
#define LOG_TAG "AEMM-JNI"
#include <utils/Log.h>
#include <utils/misc.h>

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <sys/time.h>
#include <errno.h>

// begin use for fram buffer
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <fcntl.h>

//#include "fdevent.h"
//#include "adb.h"
#include <linux/fb.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
// end use for frame buffer

/* TODO:
** - sync with vsync to avoid tearing
*/
/* This version number defines the format of the fbinfo struct.
   It must match versioning in ddms where this data is consumed. */
#define DDMS_RAWIMAGE_VERSION 1
struct fbinfo {
    unsigned int version;
    unsigned int bpp;
    unsigned int size;
    unsigned int width;
    unsigned int height;
    unsigned int red_offset;
    unsigned int red_length;
    unsigned int blue_offset;
    unsigned int blue_length;
    unsigned int green_offset;
    unsigned int green_length;
    unsigned int alpha_offset;
    unsigned int alpha_length;
} __attribute__((packed));

static void capture_framebuffer(int fd)
{
    struct fb_var_screeninfo vinfo;
    int fb, offset;
    char x[256];

    struct fbinfo fbinfo;
    unsigned i, bytespp;

    fb = open("/dev/graphics/fb0", O_RDONLY);
    if(fb < 0) {
        LOGI("error %d\n", errno);
        goto done;
    }

    if(ioctl(fb, FBIOGET_VSCREENINFO, &vinfo) < 0) goto done;
    fcntl(fb, F_SETFD, FD_CLOEXEC);

    bytespp = vinfo.bits_per_pixel / 8;

    fbinfo.version = DDMS_RAWIMAGE_VERSION;
    fbinfo.bpp = vinfo.bits_per_pixel;
    fbinfo.size = vinfo.xres * vinfo.yres * bytespp;
    fbinfo.width = vinfo.xres;
    fbinfo.height = vinfo.yres;
    fbinfo.red_offset = vinfo.red.offset;
    fbinfo.red_length = vinfo.red.length;
    fbinfo.green_offset = vinfo.green.offset;
    fbinfo.green_length = vinfo.green.length;
    fbinfo.blue_offset = vinfo.blue.offset;
    fbinfo.blue_length = vinfo.blue.length;
    fbinfo.alpha_offset = vinfo.transp.offset;
    fbinfo.alpha_length = vinfo.transp.length;

    /* HACK: for several of our 3d cores a specific alignment
     * is required so the start of the fb may not be an integer number of lines
     * from the base.  As a result we are storing the additional offset in
     * xoffset. This is not the correct usage for xoffset, it should be added
     * to each line, not just once at the beginning */
    offset = vinfo.xoffset * bytespp;

    offset += vinfo.xres * vinfo.yoffset * bytespp;

    //if(write(fd, &fbinfo, sizeof(fbinfo)) <= 0) goto done;

    lseek(fb, offset, SEEK_SET);
    for(i = 0; i < fbinfo.size; i += 256) {
        LOGI("capture frame read %d", i);
        if(read(fb, &x, 256) <= 0) goto done;
        if(write(fd, &x, 256) <= 0) goto done;
    }

    LOGI("capture frame read %d", i);

    if(read(fb, &x, fbinfo.size % 256) <= 0) goto done;
    if(write(fd, &x, fbinfo.size % 256) <= 0) goto done;

done:
    if(fb >= 0) close(fb);
    //close(fd);
    lseek(fd, 0, SEEK_SET);
}

#include "common.h"

extern "C"
int main(int argc, char* const argv[])
{
    int fd;
    struct picture pict;
    char buf[PATH_MAX];
    printf("hello capture frame buffer, %s\n", getcwd(buf, PATH_MAX));
    fd = open("/sdcard/frame", O_RDWR | O_TRUNC | O_CREAT);
    printf("fd = %d\n", fd);
    if(fd >= 0) {
        //capture_framebuffer(fd);
        if(TakeScreenshot("/dev/graphics/fb0", &pict) == 0) {
            write(fd, pict.buffer, pict.xres * pict.yres * pict.bps);
        }
        close(fd);
    }
    return 0;
}
