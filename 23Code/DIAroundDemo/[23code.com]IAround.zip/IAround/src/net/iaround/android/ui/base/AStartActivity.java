package net.iaround.android.ui.base;

import net.iaround.android.BaseActivity;

/**
 * @fileName AStartActivity.java
 * @package net.iaround.android.ui.base
 * @description 欢迎界面父类
 * @author 任东卫
 * @email 86930007@qq.com
 * @version 1.0
 */
public abstract class AStartActivity extends BaseActivity {
	// 暂时不做任何操作
}
