package net.iaround.android.ui.common;

public interface OnBackClickListener {
	public void onBackClick();
}
