package net.iaround.android.ui.common;

public interface OnMenuClickListener {
	public void onMenuClick();
}
